A simple serverless create-react-app built using AWS Lambda, DynamoDB, and API Gateways.

My tutorial on Medium about building this app: 
https://medium.com/@gulikholmatova/building-a-serverless-react-app-using-aws-lambda-dynamodb-and-an-api-gateway-f846696f34cd

Link: https://github.com/gulikholmatova/serverless-app
